-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: fantasy_football
-- ------------------------------------------------------
-- Server version	5.7.36-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coaches`
--

DROP TABLE IF EXISTS `coaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coaches` (
  `Coach_Id` int(11) NOT NULL,
  `Coach_Name` varchar(30) DEFAULT NULL,
  `Coach_Age` int(11) DEFAULT NULL,
  `C_Country` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Coach_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coaches`
--

LOCK TABLES `coaches` WRITE;
/*!40000 ALTER TABLE `coaches` DISABLE KEYS */;
INSERT INTO `coaches` VALUES (1,'Mikel Arteta',45,'Spain'),(2,'Thomas Tuchel',55,'Germany'),(3,'Jurgen Klopp',50,'Germany'),(4,'Pep Guardiola',65,'Spain'),(5,'Ralph Rangnick',35,'Germany'),(6,'Antonio Conte',60,'Italy');
/*!40000 ALTER TABLE `coaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fantasy_teams`
--

DROP TABLE IF EXISTS `fantasy_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fantasy_teams` (
  `Userid` int(11) DEFAULT NULL,
  `User_team` varchar(30) DEFAULT NULL,
  `Player_1` varchar(30) DEFAULT NULL,
  `Player_2` varchar(30) DEFAULT NULL,
  `Player_3` varchar(30) DEFAULT NULL,
  `Player_4` varchar(30) DEFAULT NULL,
  `Player_5` varchar(30) DEFAULT NULL,
  `Player_6` varchar(30) DEFAULT NULL,
  `Player_7` varchar(30) DEFAULT NULL,
  `Player_8` varchar(30) DEFAULT NULL,
  `Player_9` varchar(30) DEFAULT NULL,
  `Player_10` varchar(30) DEFAULT NULL,
  `Player_11` varchar(30) DEFAULT NULL,
  `Team_coach` varchar(30) DEFAULT NULL,
  KEY `fK_user_id` (`Userid`),
  CONSTRAINT `fK_user_id` FOREIGN KEY (`Userid`) REFERENCES `user_log_in` (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fantasy_teams`
--

LOCK TABLES `fantasy_teams` WRITE;
/*!40000 ALTER TABLE `fantasy_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `fantasy_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `Teamid` int(11) DEFAULT NULL,
  `Player_name` varchar(30) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Goals` int(11) DEFAULT NULL,
  `P_Position` varchar(30) DEFAULT NULL,
  `Player_Id` int(11) NOT NULL,
  PRIMARY KEY (`Player_Id`),
  KEY `fK_team_id` (`Teamid`),
  CONSTRAINT `fK_team_id` FOREIGN KEY (`Teamid`) REFERENCES `teams` (`Team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (1,'Aaron Ramsey',30,4,'Midfielder',1),(1,'Ainsley Maitland-Niles',23,1,'Midfielder',2),(1,'Alex Iwobi',24,3,'Forward',3),(1,'Alexandre Lacazette',29,13,'Forward',4),(1,'Bakayo Sako',0,0,'Midfielder',5),(1,'Bernd Leno',29,0,'Goalkeeper',6),(1,'Carl Jenkinson',29,0,'Defender',7),(1,'Danny Welbeck',30,1,'Forward',8),(1,'Edward Nketiah',21,1,'Forward',9),(1,'Emile Smith Rowe',20,0,'Midfielder',10),(1,'Granit Xhaka',28,4,'Midfielder',11),(1,'Hector Bellerin',26,0,'Defender',12),(1,'Henrikh Mkhitaryan',32,6,'Midfielder',13),(1,'Joseph Willock',21,0,'Midfielder',14),(1,'Konstantinos Mavropanos',23,0,'Defender',15),(1,'Laurent Koscielny',35,3,'Defender',16),(1,'Lucas Torreira',25,2,'Midfielder',17),(1,'Mohamed Elneny',28,0,'Midfielder',18),(1,'Nacho Monreal',35,1,'Defender',19),(1,'Pierre-Emerick Aubameyang',31,22,'Forward',20),(1,'Rob Holding',25,0,'Defender',21),(1,'Shkodran Mustafi',28,2,'Defender',22),(1,'Sokratis Papastathopoulos',32,1,'Defender',23),(1,'Stephan Lichtsteiner',37,0,'Defender',24),(1,'Zechariah Medley',20,0,'Defender',25),(2,'Alvaro Morata',28,5,'Forward',26),(2,'Andreas Christensen',24,0,'Defender',27),(2,'Callum Hudson-Odoi',20,0,'Midfielder',28),(2,'Cesar Azpilicueta',31,1,'Defender',29),(2,'Cesc Fabregas',33,0,'Midfielder',30),(2,'Danny Drinkwater',31,0,'Midfielder',31),(2,'David Luiz',33,3,'Defender',32),(2,'Davide Zappacosta',28,0,'Defender',33),(2,'Eden Hazard',30,16,'Midfielder',34),(2,'Emerson Palmieri dos Santos',26,0,'Defender',35),(2,'Ethan Ampadu',20,0,'Midfielder',36),(2,'Gary Cahill',35,0,'Defender',37),(2,'Gonzalo Higuain',33,5,'Forward',38),(2,'Jorginho',29,2,'Midfielder',39),(2,'Kepa Arrizabalaga',26,0,'Goalkeeper',40),(2,'Marc Guehi',20,0,'Defender',41),(2,'Marcos Alonso',30,2,'Defender',42),(2,'Olivier Giroud',34,2,'Forward',43),(2,'Pedro Rodriguez',33,8,'Midfielder',44),(2,'Ross Barkley',27,3,'Midfielder',45),(2,'Ruben Loftus-Cheek',25,6,'Midfielder',46),(2,'Victor Moses',30,0,'Midfielder',47),(2,'Wilfredo Daniel Caballero',39,0,'Goalkeeper',48),(2,'Willian',32,3,'Forward',49),(3,'Adam David Lallana',32,0,'Midfielder',50),(3,'Alberto Moreno',28,0,'Defender',51),(3,'Alex Oxlade-Chamberlain',27,0,'Midfielder',52),(3,'Alisson Becker',28,0,'Goalkeeper',53),(3,'Andrew Robertson',27,0,'Defender',54),(3,'Curtis Jones',20,0,'Midfielder',55),(3,'Daniel Sturridge',31,2,'Forward',56),(3,'Dejan Lovren',31,1,'Defender',57),(3,'Divock Origi',25,3,'Forward',58),(3,'Fabinho',27,1,'Midfielder',59),(3,'Georginio Wijnaldum',30,3,'Midfielder',60),(3,'James Milner',35,5,'Midfielder',61),(3,'Joe Gomez',23,0,'Defender',62),(3,'Joel Matip',29,1,'Defender',63),(3,'Jordan Henderson',30,1,'Midfielder',64),(3,'Loris Karius',27,0,'Goalkeeper',65),(3,'Mohamed Salah',28,22,'Forward',66),(3,'Rafael Euclides Soares Camacho',20,0,'Midfielder',67),(3,'Roberto Firmino',29,12,'Forward',68),(3,'Simon Mignolet',33,0,'Goalkeeper',69),(3,'Trent Alexander-Arnold',22,1,'Defender',70),(3,'Virgil van Dijk',29,4,'Defender',71),(3,'Xherdan Shaqiri',29,6,'Midfielder',72),(4,'Arijanet Muric',22,0,'Goalkeeper',73),(4,'Aymeric Laporte',26,3,'Defender',74),(4,'Benjamin Mendy',26,0,'Defender',75),(4,'Bernardo Silva',26,7,'Midfielder',76),(4,'Danilo',29,1,'Defender',77),(4,'David Silva',35,6,'Midfielder',78),(4,'Ederson',27,0,'Goalkeeper',79),(4,'Fabian Delph',31,0,'Midfielder',80),(4,'Fernando Luiz Rosa',35,1,'Midfielder',81),(4,'Gabriel Jesus',24,7,'Forward',82),(4,'John Stones',26,0,'Defender',83),(4,'Kevin De Bruyne',29,2,'Midfielder',84),(4,'Kyle Walker',30,1,'Defender',85),(4,'Nicolas Otamendi',33,0,'Defender',86),(4,'Oleksandr Zinchenko',24,0,'Midfielder',87),(4,'Philip Foden',20,1,'Midfielder',88),(4,'Philippe Sandler',24,0,'Defender',89),(4,'Raheem Sterling',26,17,'Forward',90),(4,'Riyad Mahrez',30,7,'Midfielder',91),(4,'Sergio Aguero',32,21,'Forward',92),(4,'Vincent Kompany',34,1,'Defender',93),(5,'Alexis Sanchez',32,1,'Forward',94),(5,'Ander Herrera',31,2,'Midfielder',95),(5,'Andreas Pereira',25,1,'Midfielder',96),(5,'Angel Gomes',20,0,'Midfielder',97),(5,'Anthony Martial',25,10,'Forward',98),(5,'Antonio Valencia',35,0,'Defender',99),(5,'Ashley Young',35,2,'Midfielder',100),(5,'Chris Smalling',31,1,'Defender',101),(5,'David de Gea',30,0,'Goalkeeper',102),(5,'Eric Bertrand Bailly',26,0,'Defender',103),(5,'Faustino Marcos Alberto Rojo',31,0,'Defender',104),(5,'Frederico Rodrigues Santos',28,1,'Midfielder',105),(5,'James Garner',20,0,'Defender',106),(5,'Jesse Lingard',28,4,'Midfielder',107),(5,'Juan Mata',32,3,'Midfielder',108),(5,'Lee Grant',38,0,'Goalkeeper',109),(5,'Luke Shaw',25,1,'Defender',110),(5,'Marcus Rashford',23,10,'Forward',111),(5,'Marouane Fellaini',33,0,'Midfielder',112),(5,'Mason Greenwood',19,0,'Midfielder',113),(5,'Matteo Darmian',31,0,'Defender',114),(5,'Paul Pogba',28,13,'Midfielder',115),(5,'Phil Jones',29,0,'Defender',116),(5,'Romelu Lukaku',27,12,'Forward',117),(5,'Scott McTominay',24,2,'Midfielder',118),(5,'Tahith Chong',21,0,'Forward',119),(6,'Alfie Whiteman',22,0,'Goalkeeper',120),(6,'Ben Davies',27,0,'Defender',121),(6,'Christian Eriksen',29,8,'Midfielder',122),(6,'Danny Rose',30,0,'Defender',123),(6,'Dele Alli',24,5,'Midfielder',124),(6,'Eric Dier',27,3,'Midfielder',125),(6,'Erik Lamela',29,4,'Midfielder',126),(6,'Fernando Llorente Torres',36,1,'Forward',127),(6,'George Marsh',22,0,'Midfielder',128),(6,'Harry Kane',27,17,'Forward',129),(6,'Harry Winks',25,1,'Midfielder',130),(6,'Heung-Min Son',28,12,'Forward',131),(6,'Hugo Lloris',34,0,'Goalkeeper',132),(6,'Jan Vertonghen',33,1,'Defender',133),(6,'Juan Marcos Foyth',23,1,'Defender',134),(6,'Kazaiah Sterling',22,0,'Forward',135),(6,'Kieran Trippier',30,1,'Defender',136),(6,'Kyle Walker-Peters',23,0,'Defender',137),(6,'Lucas Rodrigues Moura da Silva',28,10,'Midfielder',138),(6,'Luke Amos',24,0,'Midfielder',139),(6,'Michel Vorm',37,0,'Goalkeeper',140),(6,'Moussa Dembele',33,0,'Midfielder',141),(6,'Moussa Sissoko',31,0,'Midfielder',142),(6,'Oliver Skipp',20,0,'Midfielder',143),(6,'Paulo Dino Gazzaniga',29,0,'Goalkeeper',144),(6,'Serge Aurier',28,0,'Defender',145),(6,'Timothy Eyoma',21,0,'Defender',146),(6,'Toby Alderweireld',32,0,'Defender',147),(6,'Victor Wanyama',29,1,'Midfielder',148),(6,'Vincent Janssen',26,0,'Forward',149);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `C_id` int(11) DEFAULT NULL,
  `Team_id` int(11) NOT NULL,
  `Team_name` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Matches_played` varchar(30) DEFAULT NULL,
  `Won` int(11) DEFAULT NULL,
  `Lost` int(11) DEFAULT NULL,
  PRIMARY KEY (`Team_id`),
  KEY `fK_coach_id` (`C_id`),
  CONSTRAINT `fK_coach_id` FOREIGN KEY (`C_id`) REFERENCES `coaches` (`Coach_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,1,'Arsenal','England','38',21,17),(2,2,'Chelsea','England','38',22,16),(3,3,'Liverpool','England','38',38,0),(4,4,'Manchester_City','England','38',35,3),(5,5,'Manchester_United','England','38',12,26),(6,6,'Tottenham_Hotspurs','England','38',15,23);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_log_in`
--

DROP TABLE IF EXISTS `user_log_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_log_in` (
  `Username` varchar(30) DEFAULT NULL,
  `User_Id` int(11) NOT NULL AUTO_INCREMENT,
  `User_password` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_log_in`
--

LOCK TABLES `user_log_in` WRITE;
/*!40000 ALTER TABLE `user_log_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_log_in` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-09 17:42:51
